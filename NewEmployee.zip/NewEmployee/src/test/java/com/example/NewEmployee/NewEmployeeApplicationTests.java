package com.example.NewEmployee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
