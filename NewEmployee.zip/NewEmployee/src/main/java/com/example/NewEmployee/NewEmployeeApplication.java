package com.example.NewEmployee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewEmployeeApplication.class, args);
	}

}
